function hn=FilterCoeQuant; 
fs=2000;                   %sampling freq
fc=[300,600];            %transition band
mag=[0 1];                 %magnitude
dev=[0.001 0.01];          %ripple

[n,wn,beta,ftype]=kaiserord(fc,mag,dev,fs);
fpm=[0 fc(1)*2/fs fc(2)*2/fs 1];
magpm=[0 0 1 1];
%Use kaiserord to get n, then use firpm to get the best filter

h_pm=firpm(n,fpm,magpm);  %ideal
h_pm12=round(h_pm/max(abs(h_pm))*(2^11-1)); %12 bit quantification 
h_pm13=round(h_pm/max(abs(h_pm))*(2^12-1)); %13 bit quantification
h_pm14=round(h_pm/max(abs(h_pm))*(2^13-1)); %14 bit quantification
hn=h_pm13;
%Number system conversion
q14_bin_pm=dec2bin(h_pm14+2^14*(h_pm14<0))
q13_bin_pm=dec2bin(h_pm13+2^13*(h_pm13<0))

%Write into hpf14.txt
fid=fopen('C:\Personal\Digital_IC_Design\Projects\FIR\MATLAB\hpf14.txt','w');
for i=1:length(q14_bin_pm)
fprintf(fid,'%13s\r\n',char(q13_bin_pm(i, :)));
end
fprintf(fid,';');
fclose(fid);

%Display
m_pm=20*log(abs(fft(h_pm,1024)))/log(10); m_pm=m_pm-max(m_pm);
m_pm12=20*log(abs(fft(h_pm12,1024)))/log(10); m_pm12=m_pm12-max(m_pm12);
m_pm13=20*log(abs(fft(h_pm13,1024)))/log(10); m_pm13=m_pm13-max(m_pm13);
m_pm14=20*log(abs(fft(h_pm14,1024)))/log(10); m_pm14=m_pm14-max(m_pm14);

x_f=[0:(fs/length(m_pm)):fs/2];

mf_pm=m_pm(1:length(x_f));
mf_pm12=m_pm12(1:length(x_f));
mf_pm13=m_pm13(1:length(x_f));
mf_pm14=m_pm14(1:length(x_f));%Only display the positive part

plot(x_f,mf_pm,'-',x_f,mf_pm12,'-.',x_f,mf_pm13,'--',x_f,mf_pm14,':');
xlabel('Frequency(Hz)'); ylabel('Magnitude(dB20)');
legend('ideal','12bit','13bit','14bit');
grid;