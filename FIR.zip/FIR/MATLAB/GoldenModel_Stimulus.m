%Test signal generating and Ideal results
f1=200;       %freq1=200Hz
f2=800;       %freq2=800Hz
fsq=200;      %freq square wave=200Hz
ftr=400;      %freq triangle wave=400Hz
Fs=2000;      %sample freq=2KHz
N=13;         %quantization bits of Xin=13

width=0.5;   %width of triangle wave =0.5
duty=50;     %duty of square wave =50
%Generate signal
t=0:1/Fs:1;
c1=2*pi*f1*t;
c2=2*pi*f2*t;
csq=2*pi*fsq*t;
ctr=2*pi*ftr*t;

sq=square(csq,duty);%generate square wave
tr=sawtooth(ctr,width);%generate triangle wave

s1=sin(c1);%generate sin 1
s2=sin(c2);%generate sin 2
s=s1+s2;   %generate harmonic
noise=randn(1,length(t));%generate gaussian white noise

%normalize
noise=noise/max(abs(noise));
s=s/max(abs(s));
sq=sq/max(abs(sq));
tr=tr/max(abs(tr));

%13 bit quantification
Q_noise=round(noise*(2^(N-1)-1));
Q_s=round(s*(2^(N-1)-1));
Q_sq=round(sq*(2^(N-1)-1));
Q_tr=round(tr*(2^(N-1)-1));

%Filtering
hn=FilterCoeQuant; 
Filter_noise=filter(hn,1,Q_noise);
Filter_s=filter(hn,1,Q_s);
Filter_sq=filter(hn,1,Q_sq);
Filter_tr=filter(hn,1,Q_tr);

%Get the magnitude of original signal
m_noise=20*log(abs(fft(Q_noise,1024)))/log(10); m_noise=m_noise-max(m_noise);
m_s=20*log(abs(fft(Q_s,1024)))/log(10); m_s=m_s-max(m_s);
m_sq=20*log(abs(fft(Q_sq,1024)))/log(10); m_sq=m_sq-max(m_sq);
m_tr=20*log(abs(fft(Q_tr,1024)))/log(10); m_tr=m_tr-max(m_tr);

%Get the magnitude of filtered signal
Fm_noise=20*log(abs(fft(Filter_noise,1024)))/log(10); Fm_noise=Fm_noise-max(Fm_noise);
Fm_s=20*log(abs(fft(Filter_s,1024)))/log(10); Fm_s=Fm_s-max(Fm_s);
Fm_sq=20*log(abs(fft(Filter_sq,1024)))/log(10); Fm_sq=Fm_sq-max(Fm_sq);
Fm_tr=20*log(abs(fft(Filter_tr,1024)))/log(10); Fm_tr=Fm_tr-max(Fm_tr);

%The magnitude of the filter
m_hn=20*log(abs(fft(hn,1024)))/log(10); m_hn=m_hn-max(m_hn);

%Display signal setting
x_f=0:(Fs/length(m_s)):Fs/2;
mf_noise=m_noise(1:length(x_f));
mf_s=m_s(1:length(x_f));
mf_sq=m_sq(1:length(x_f));
mf_tr=m_tr(1:length(x_f));

Fmf_noise=Fm_noise(1:length(x_f));
Fmf_s=Fm_s(1:length(x_f));
Fm_hn=m_hn(1:length(x_f));
Fmf_sq=Fm_sq(1:length(x_f));
Fmf_tr=Fm_tr(1:length(x_f));

%Display
subplot(2,2,1)
plot(x_f,mf_noise,'-.',x_f,Fmf_noise,'-',x_f,Fm_hn,'--');
xlabel('Frequency(Hz)');ylabel('Magnitude(dB)');title('Ideal Frequency Responce of Noise');
legend('Input Signal','Output Signal','Filter');
grid;

subplot(2,2,2)
plot(x_f,mf_s,'-.',x_f,Fmf_s,'-',x_f,Fm_hn,'--');
xlabel('Frequency(Hz)');ylabel('Magnitude(dB)');title('Ideal Frequency Responce of Harmonic');
legend('Input Signal','Output Signal','Filter');
grid;

subplot(2,2,3)
plot(x_f,mf_sq,'-.',x_f,Fmf_sq,'-',x_f,Fm_hn,'--');
xlabel('Frequency(Hz)');ylabel('Magnitude(dB)');title('Ideal Frequency Responce of Square Wave');
legend('Input Signal','Output Signal','Filter');
grid;

subplot(2,2,4)
plot(x_f,mf_tr,'-.',x_f,Fmf_tr,'-',x_f,Fm_hn,'--');
xlabel('Frequency(Hz)');ylabel('Magnitude(dB)');title('Ideal Frequency Responce of Triangle Wave');
legend('Input Signal','Output Signal','Filter');
grid;

%Writing input signal for ResultsCompare
fid=fopen('C:\Personal\Digital_IC_Design\Projects\FIR\FPGA\Test_input\in_noise.txt','w');
fprintf(fid,'%8d\r\n',Q_noise);
fprintf(fid,';'); 
fclose(fid);

fid=fopen('C:\Personal\Digital_IC_Design\Projects\FIR\FPGA\Test_input\in_s.txt','w');
fprintf(fid,'%8d\r\n',Q_s);
fprintf(fid,';'); 
fclose(fid);

fid=fopen('C:\Personal\Digital_IC_Design\Projects\FIR\FPGA\Test_input\in_sq.txt','w');
fprintf(fid,'%8d\r\n',Q_sq);
fprintf(fid,';'); 
fclose(fid);

fid=fopen('C:\Personal\Digital_IC_Design\Projects\FIR\FPGA\Test_input\in_tr.txt','w');
fprintf(fid,'%8d\r\n',Q_tr);
fprintf(fid,';'); 
fclose(fid);

%Writing stimulus signal for simulation.
fid=fopen('C:\Personal\Digital_IC_Design\Projects\FIR\FPGA\Test_input\Bin_noise.txt','w');
for i=1:length(Q_noise)
    B_noise=dec2bin(Q_noise(i)+(Q_noise(i)<0)*2^N,N);
    for j=1:N
       if B_noise(j)=='1'
           tb=1;
       else
           tb=0;
       end
       fprintf(fid,'%d',tb);  
    end
    fprintf(fid,'\r\n');
end
fprintf(fid,';'); 
fclose(fid);


fid=fopen('C:\Personal\Digital_IC_Design\Projects\FIR\FPGA\Test_input\Bin_s.txt','w');
for i=1:length(Q_s)
    B_s=dec2bin(Q_s(i)+(Q_s(i)<0)*2^N,N);
    for j=1:N
       if B_s(j)=='1'
           tb=1;
       else
           tb=0;
       end
       fprintf(fid,'%d',tb);  
    end
    fprintf(fid,'\r\n');
end
fprintf(fid,';'); 
fclose(fid);

fid=fopen('C:\Personal\Digital_IC_Design\Projects\FIR\FPGA\Test_input\Bin_sq.txt','w');
for i=1:length(Q_sq)
    B_sq=dec2bin(Q_sq(i)+(Q_sq(i)<0)*2^N,N);
    for j=1:N
       if B_sq(j)=='1'
           tb=1;
       else
           tb=0;
       end
       fprintf(fid,'%d',tb);  
    end
    fprintf(fid,'\r\n');
end
fprintf(fid,';'); 
fclose(fid);

fid=fopen('C:\Personal\Digital_IC_Design\Projects\FIR\FPGA\Test_input\Bin_tr.txt','w');
for i=1:length(Q_tr)
    B_tr=dec2bin(Q_tr(i)+(Q_tr(i)<0)*2^N,N);
    for j=1:N
       if B_tr(j)=='1'
           tb=1;
       else
           tb=0;
       end
       fprintf(fid,'%d',tb);  
    end
    fprintf(fid,'\r\n');
end
fprintf(fid,';'); 
fclose(fid);
