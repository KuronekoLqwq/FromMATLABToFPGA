%Read the results and compare it
f1=200;       %freq1=200Hz
f2=800;       %freq2=800Hz
fsq=200;      %freq square wave=500Hz
ftr=400;      %freq triangle wave=500Hz
Fs=2000;      %sample freq=2KHz


%Read the input signal
fid=fopen('C:\Personal\Digital_IC_Design\Projects\FIR\FPGA\Test_input\in_noise.txt','r');
[Noise_in,N_n]=fscanf(fid,'%lg',inf);
fclose(fid);

fid=fopen('C:\Personal\Digital_IC_Design\Projects\FIR\FPGA\Test_input\in_s.txt','r');
[S_in,S_n]=fscanf(fid,'%lg',inf);
fclose(fid);

fid=fopen('C:\Personal\Digital_IC_Design\Projects\FIR\FPGA\Test_input\in_sq.txt','r');
[Sq_in,Sq_n]=fscanf(fid,'%d',inf);
fclose(fid);

fid=fopen('C:\Personal\Digital_IC_Design\Projects\FIR\FPGA\Test_input\in_tr.txt','r');
[Tr_in,Tr_n]=fscanf(fid,'%d',inf);
fclose(fid);

%Read the output of FIR from fpga
fid=fopen('C:\Personal\Digital_IC_Design\Projects\FIR\FPGA\Test_output\Output_noise.txt','r');
[Noise_out,N_count]=fscanf(fid,'%d',inf);
fclose(fid);

fid=fopen('C:\Personal\Digital_IC_Design\Projects\FIR\FPGA\Test_output\Output_s.txt','r');
[S_out,S_count]=fscanf(fid,'%d',inf);
fclose(fid);

fid=fopen('C:\Personal\Digital_IC_Design\Projects\FIR\FPGA\Test_output\Output_sq.txt','r');
[Sq_out,Sq_count]=fscanf(fid,'%d',inf);
fclose(fid);

fid=fopen('C:\Personal\Digital_IC_Design\Projects\FIR\FPGA\Test_output\Output_tr.txt','r');
[Tr_out,Tr_count]=fscanf(fid,'%d',inf);
fclose(fid);

%Normalization
Noise_out=Noise_out/max(abs(Noise_out));
S_out=S_out/max(abs(S_out));
Sq_out=Sq_out/max(abs(Sq_out));
Tr_out=Tr_out/max(abs(Tr_out));

Noise_in=Noise_in/max(abs(Noise_in));
S_in=S_in/max(abs(S_in));
Sq_in=Sq_in/max(abs(Sq_in));
Tr_in=Tr_in/max(abs(Tr_in));

%Frequency Responce
out_noise=20*log10(abs(fft(Noise_out,1024))); out_noise=out_noise-max(out_noise);
out_s=20*log10(abs(fft(S_out,1024))); out_s=out_s-max(out_s);
out_sq=20*log10(abs(fft(Sq_out,1024))); out_sq=out_sq-max(out_sq);
out_tr=20*log10(abs(fft(Tr_out,1024))); out_tr=out_tr-max(out_tr);

in_noise=20*log10(abs(fft(Noise_in,1024))); in_noise=in_noise-max(in_noise);
in_s=20*log10(abs(fft(S_in,1024))); in_s=in_s-max(in_s);
in_sq=20*log10(abs(fft(Sq_in,1024))); in_sq=in_sq-max(in_sq);
in_tr=20*log10(abs(fft(Tr_in,1024))); in_tr=in_tr-max(in_tr);

%Frequency Responce of the filter
hn=FilterCoeQuant;
m_hn=20*log(abs(fft(hn,1024)))/log(10); m_hn=m_hn-max(m_hn);

%Set the X axis
x_f=0:(Fs/length(out_noise)):Fs/2;

%Display
mf_noise=out_noise(1:length(x_f));
mf_s=out_s(1:length(x_f));
mf_sq=out_sq(1:length(x_f));
mf_tr=out_tr(1:length(x_f));

mf_in_noise=in_noise(1:length(x_f));
mf_in_s=in_s(1:length(x_f));
mf_in_sq=in_sq(1:length(x_f));
mf_in_tr=in_tr(1:length(x_f));

mf_hn=m_hn(1:length(x_f));

figure(2);
subplot(2,2,1);
plot(x_f,mf_in_noise,'--',x_f,mf_noise,'-',x_f,mf_hn,'--');
xlabel('Freq(Hz)');ylabel('Magnitude(dB)');title('FPGA Frequency Responce of Noise');
legend('Input Signal','Output Signal','Filter');
grid;
subplot(2,2,2);
plot(x_f,mf_in_s,'--',x_f,mf_s,'-',x_f,mf_hn,'--');
xlabel('Freq(Hz)');ylabel('Magnitude(dB)');title('FPGA Frequency Responce of Harmonic');
legend('Input Signal','Output Signal','Filter');
grid;
subplot(2,2,3);
plot(x_f,mf_in_sq,'--',x_f,mf_sq,'-',x_f,mf_hn,'--');
xlabel('Freq(Hz)');ylabel('Magnitude(dB)');title('FPGA Frequency Responce of Square Wave');
legend('Input Signal','Output Signal','Filter');
grid;
subplot(2,2,4);
plot(x_f,mf_in_tr,'--',x_f,mf_tr,'-',x_f,mf_hn,'--');
xlabel('Freq(Hz)');ylabel('Magnitude(dB)');title('FPGA Frequency Responce of Triangle Wave');
legend('Input Signal','Output Signal','Filter');
grid;