The FPGA part contains 2 kinds of implementation of FIR: Serial and DataBroadcasting. 
Because there is enough simulation time for each stimulus, the infulence of wrong connection parts in the tb is tiny enough. 

The MATLAB part contains 3 parts: FIR Design(FilterCoeQuant), Ideal Results and Stimuls Generation(GoldenModel_Stimulus), ResultsCompare(ResultsCompare)

In Ref part, there are codes and books I refer to finish the projects. 

In results part, the time, area, power of 2 FIR, and the functional results from MATLAB are illustrated. Obviously you can find the improvement of databroadcasting structure. 
The clock is set to 20ns. 